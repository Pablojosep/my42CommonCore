/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ppenuela <ppenuela@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/17 19:38:40 by ppenuela          #+#    #+#             */
/*   Updated: 2024/08/02 23:21:03 by ppenuela         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

char	*gnl_bufferhandler(char *string)
{
	char		*temp;
	size_t		i;
	int			k;

	i = 0;
	k = 0;
	if (string == NULL || string[0] == '\0')
		return (NULL);
		//return(free(string), NULL);
	while (string[i] != '\n')
		++i;
	if (ft_strlen(string) - 1 == i)
		//return (free(string),NULL);
		return (NULL);
	temp = malloc(sizeof(char *) * (ft_strlen(string) - i++));// fi es uma nerd
	while (string[i] != '\0')
		temp[k++] = string[i++];	
	temp[k] = '\0';
	return (temp);
	//return (free(string), temp);
}

char	*gnl_readingshandler(char *buffer)
{
	char	*string;
	int		i;
	
	i = 0;
	if (buffer == NULL)
		return (NULL);
	while (buffer[i] != '\n')
		++i;
	string = malloc (sizeof(char *) * (i + 2));
	i = 0;
	while (buffer[i] != '\n')
	{
		string[i] = buffer[i];
		++i;
	}
	string[i] = '\n';
	string[i + 1] = '\0';
	return (string);
}

char	*use_read(int fd, char *buffer)
{
	char	*readings;
	char	*temp;
	char	*temp2;
	int		readresult;

	readings = malloc(sizeof(char) * (BUFFER_SIZE + 1));
	readresult = read(fd, readings, BUFFER_SIZE);
	if (readresult == 0)
		return (free (readings), buffer);
	readings[readresult] = '\0';
	temp = ft_strdup(buffer);
	while (ft_strchr(readings, '\n') == NULL && readresult != 0)
	{
		temp2 = ft_strjoin(temp, readings);
		free(temp);
		free(readings);
		readings = malloc(sizeof(char) * (BUFFER_SIZE + 1));//
		readresult = read(fd, readings, BUFFER_SIZE);
		readings[readresult] = '\0';
		temp = ft_strdup(temp2);
		free(temp2);
	}
	temp2 = ft_strjoin(temp,readings);
	return (free(temp), free(readings), temp2);
}



char	*get_next_line(int fd)
{
	static char	*store;
	char		*result;
	char		*helper;
	char		*temporal;
	
	if (fd < 0 || BUFFER_SIZE <= 0)
		return (NULL);
	if (!store)
		store = "";
	helper = use_read(fd, store);
	if (ft_strlen(helper) == 0 && ft_strlen(store) == 0)
		return (NULL);
	result = gnl_readingshandler(helper);
	temporal = gnl_bufferhandler(helper);
	if (ft_strlen(temporal) > 0)
	{
		store = malloc (sizeof(char *) * (ft_strlen(temporal) + 1));
		if (!store)
			return (free (helper),free(result), free(temporal), NULL);
		ft_memcpy(store, temporal, ft_strlen(temporal) + 1);
	}
	else
		store = "";
	return (free(temporal), free(helper), result);
}
